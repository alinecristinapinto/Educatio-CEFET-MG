<!DOCTYPE html>
<html>
<head>
	<title>Alterar Departamento</title>
</head>
<body>
	<h1>Alterar Departamento</h1>
	<form method="POST" action="">	
		<select name="Onde">
			<option>Nome</option>	
			<option>Id</option>
		</select>
		<input type="text" name="dado" placeholder="Pesquisar"/><br>
		<select name="Onde">
			<option>Nome</option>
			<option>Id</option>
			<option>Id-Campi</option>
		</select>
		<input type="text" name="dado1" placeholder="O que alterar?"><br><br>
		<input type="submit" value="Alterar">	
	</form>
</body>
</html>

<?php
header('charset=utf-8');

	$servername = "localhost";
	$username = "root";
	$password = null;
	$dbname = "Educatio";

	//Recebe os Dados do Form 
	@$Opc = $_POST['Opc'];
	@$Onde = $_POST['Onde'];
	@$dado = $_POST['dado'];

	$aux1 = null;
	$aux2 = null;

	//Cria conexão
	$conn = new mysqli($servername, $username, $password);
	//Verifica conexão
	if ($conn->connect_error) {
   		die("Falha na conexão: " . $conn->connect_error."<br>");
	} 

 	//Alterar Id-campi
 	if ($Onde == "Id-campi") {	
		//Pesquisr por Id, Nome ou Id-campi
		if($Opc == "Id"){
			$aux1 = "id = '".$dado1."' ";
		}else if($Opc == "Nome"){
			$aux1 = "nome = '".$dado1."' ";
		}else if($Opc == "Id-campi"){
			$aux1 = "idCampi = '".$dado1."' ";
		}
			
		@$aux2 = " WHERE idCampi = '".$dado."'";

	//Alterar o Nome
	}else if ($Onde == "Nome") {
			
  		//Pesquisr por Id, Nome ou Id-campi
		if($Opc == "Id"){
			$aux1 = "id = '".$dado1."' ";
		}else if($Opc == "Nome"){
			$aux1 = "nome = '".$dado1."' ";
		}else if($Opc == "Id-campi"){
			$aux1 = "idCampi = '".$dado1."' ";
		}
			
		@$aux2 = " WHERE nome = '".$dado."'";

	}

	//Parametro de SQL
	@$sql = "UPDATE `Educatio`.`deptos` SET ".$aux1;

	echo $sql."<br>";
	echo $aux1;

	//Verifica se o Departamento foi alterado 
	if ($conn->query($sql) === TRUE) {
    	echo "Deparatamento alterado com sucesso";
	} else {
    	echo "Erro alterando o Deparatamento: ".$conn->error;
	} 

	//Fecha a conexão
	$conn->close();
?>