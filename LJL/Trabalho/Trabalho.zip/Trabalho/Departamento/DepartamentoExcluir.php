<!DOCTYPE html>
<html>
<head>
	<title>Excluir Departamento</title>
</head>
<body>

	<h1>Excluir Departamento</h1>

	<form action="" method="POST">

		<select name="Opc">
			<option>Nome</option>
			<option>Id</option>
		</select>
		<input type="text" name="dado" placeholder="Pesquisar"><br><br>
		<input type="submit" name="" value="Excluir">
		
	</form>

</body>
</html>

<?php

header('charset=utf-8');

	$servername = "localhost";
	$username = "root";
	$password = null;
	$dbname = "Educatio";
	
	//Recebe os Dados do Form
	@$Opc = $_POST['Opc'];
	@$dado = $_POST['dado'];

	//Cria conexão
	$conn = new mysqli($servername, $username, $password);
	//Verifica conexão
	if ($conn->connect_error) {
   		die("Falha na conexão: " . $conn->connect_error."<br>");
	}

	//verifica se a pesquisa vai ser feita por Id ou Nome
	if($Opc == "Id"){
		$aux = "id = '".$dado."'";
	}else if($Opc == "Nome"){
		$aux = "nome = '".$dado."'";
	}

	//Parametro em SQL  		
	@$sql = "UPDATE `Educatio`.`deptos` SET ativo = 'n' WHERE ".$aux;

	//Verifica se o Departamento foi "excluido"
 	if ($conn->query($sql) === TRUE) {
	    echo "Deparatamento deletado com sucesso";
	} else {
	    echo "Erro deletando o Departamento: ".$conn->error;
	} 
	
	//Fecha a conexão
	$conn->close();

?>