<!DOCTYPE html>
<html>
<head>
	<title>Adicionar Depratamento</title>
</head>
<body>

	<h1>Adicionar Novo Departamento</h1>

	<form action="" method="POST">

		<input type="text" name="nome" placeholder="Nome"><br>
		<input type="text" name="Idcampi" placeholder="ID-Campi"><br><br>
		<input type="submit" name="" value="Incluir">
		
	</form>

</body>
</html>

<?php
header('charset=utf-8');

	$servername = "localhost";
	$username = "root";
	$password = null;
	$dbname = "educatio";
	
	//Recebe os Dados do Form
	@$Idcampi = $_POST['Idcampi'];
	@$nome = $_POST['nome'];

	$Id = 1;

	//Cria conexão
	$conn = new mysqli($servername, $username, $password);
	//Verifica conexão
	if ($conn->connect_error) {
   		die("Falha na conexão: " . $conn->connect_error."<br>");
	}

	//Parametro de SQL  
	$sql = "INSERT INTO `Educatio`.`deptos` (idCampi, nome, ativo) VALUES ('".$Idcampi."', '".$nome."', 's')";

	//Verifica se o Departamento foi criado com sucesso
	if ($conn->query($sql) === TRUE) {
    	echo "Deparatamento criado com sucesso";
	} else {
    	echo "Erro criando o Deparatamento: ".$conn->error;
	}

	//Fecha a conexão
	$conn->close();
?>