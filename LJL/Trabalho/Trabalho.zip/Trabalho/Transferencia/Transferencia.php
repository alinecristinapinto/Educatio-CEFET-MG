<!DOCTYPE html>
<html>
<head>
	<title>Transfer�ncia de Aluno</title>
	<meta charset="utf-8">
</head>
<body>

	<script>
		function formatar(src, mask) {	
  			var i = src.value.length;
  			var saida = mask.substring(0,1);
  			var texto = mask.substring(i)
			if (texto.substring(0,1) != saida) {
                src.value += texto.substring(0,1);
  			}
		}
	</script>

	<h1>Transferencia de Aluno</h1>

	<form method="POST" action="">

		<input type="text" name="CPF" onkeypress="formatar(this,'000.000.000-00')" placeholder="Digite o CPF do aluno"><br>
		<input type="submit" name="Enviar" value="Enviar">
		
	</form>
	 
</body>
</html>

<?php  

	header('charset=utf-8');

	$servername = "localhost";
	$username = "root";
	$password = null;
	$dbname = "Educatio";

	//Cria conex�o
	$conn = new mysqli($servername, $username, $password);
	//Verifica conex�o
	if ($conn->connect_error) {
   		die("Falha na conex�o: " . $conn->connect_error."<br>");
	}

	//recebe o CPF do Form
	@$cpf = $_POST['CPF'];

	//Verificar se o  CPF est� valido  
	if (isset($_POST['CPF'])) {
		if (preg_match("/^[0-9]{3}\.[0-9]{3}\.[0-9]{3}-[0-9]{2}$/", $cpf)){
  			echo "CPF v�lido.<br>";
		} else {
  			echo "CPF inv�lido.<br>";
		}
	}

	//Tirar os "." e "-" do CPF para pesquisar no DB
	$prt1 = substr($cpf, 0, 3);
	$prt2 = substr($cpf, 4, 3);
	$prt3 = substr($cpf, 8, 3);
	$prt4 = substr($cpf, 12);

	$cpf = $prt1.$prt2.$prt3.$prt4;

	echo $cpf;

	@$sql = "UPDATE `Educatio`.`alunos` SET ativo = 'n' WHERE idCPF = '".$cpf."'";

	//Verifica se o Departamento foi "excluido"
 	if ($conn->query($sql) === TRUE) {
	    echo "Aluno tranferido com sucesso";
	} else {
	    echo "Erro transferindo Aluno: ".$conn->error;
	} 

?>